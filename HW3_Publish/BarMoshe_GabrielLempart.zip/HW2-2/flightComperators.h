#pragma once

int compareFlightBySourceName(const void **f1, const void **f2);
int compareFlightByDestName(const void **f1, const void **f2);
int compareFlightByPlainCode(const void **f1, const void **f2);
int compareFlightByDate(const void **f1, const void **f2);
